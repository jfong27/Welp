//
//  Review.swift
//  Welp
//
//  Created by Jason Fong on 3/1/19.
//  Copyright © 2019 Jason Fong. All rights reserved.
//

import Foundation

class Review  {
    
    
}
