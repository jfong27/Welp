#  Welp

## Device 
I used the iPhone X simulator to test Welp. For some reason, I got some bugs with the map and profile when using my iPad. I don't know if it's because it's a physical device or because it's an iPad.  

## Test Account
You can use the test account, or create a new account, or sign in with Facebook.  
Email: test@welp.com   
Pwd: 123456

## Other
- You can add a profile picture, but I haven't implemented adding photos to reviews yet. 
- Search is not implemented yet. 
- There is a bug when adding a new review from the search tab. Duplicate reviews appear.
- Must use xcworkspace and not xcodeproject
- I simulated my location as Cal Poly and ad
- My simulated coordinates were (35.302756, -120.662742)
