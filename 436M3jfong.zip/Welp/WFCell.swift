//
//  WFCell.swift
//  Welp
//
//  Created by Jason Fong on 2/13/19.
//  Copyright © 2019 Jason Fong. All rights reserved.
//

import UIKit

class WFCell: UITableViewCell {

    @IBOutlet weak var nameLabel: UILabel!

    
}
